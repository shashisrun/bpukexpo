import { StatusBar } from 'expo-status-bar';
import * as React from 'react';
import { Platform, StyleSheet,TouchableOpacity } from 'react-native';

import EditScreenInfo from '../components/EditScreenInfo';
import { Text, View } from '../components/Themed';
import Bottom from '../components/Bottom';
import { ScrollView } from 'react-native-gesture-handler';

export default function NotificationScreen() {
  return (
    <ScrollView>
      <View style={styles.NotificationTab}>
    <View style={styles.NotificationSubTab1}>
      <Text style={{fontSize:25,paddingVertical:10,}}>Zone</Text>
      <Text style={{fontSize:17,paddingVertical:5,}} >Event</Text>
    </View>
    <View style={styles.NotificationSubTab2}>
      <TouchableOpacity style={styles.NotificationTouchableOpacity1}>
        <Text style={styles.Notification_btn}>Cancel</Text>
      </TouchableOpacity>
      </View>
    </View>


    <View style={styles.NotificationTab}>
    <View style={styles.NotificationSubTab1}>
      <Text style={{fontSize:25,paddingVertical:10,}}>Zone</Text>
      <Text style={{fontSize:17,paddingVertical:5,}} >Event</Text>
    </View>
    <View style={styles.NotificationSubTab2}>
      <TouchableOpacity style={styles.NotificationTouchableOpacity1}>
        <Text style={styles.Notification_btn}>Cancel</Text>
      </TouchableOpacity>
      </View>
    </View>


    <View style={styles.NotificationTab}>
    <View style={styles.NotificationSubTab1}>
      <Text style={{fontSize:25,paddingVertical:10,}}>Zone</Text>
      <Text style={{fontSize:17,paddingVertical:5,}} >Event</Text>
    </View>
    <View style={styles.NotificationSubTab2}>
      <TouchableOpacity style={styles.NotificationTouchableOpacity1}>
        <Text style={styles.Notification_btn}>Cancel</Text>
      </TouchableOpacity>
      </View>
    </View>

    <View style={styles.NotificationTab}>
    <View style={styles.NotificationSubTab1}>
      <Text style={{fontSize:25,paddingVertical:10,}}>Zone</Text>
      <Text style={{fontSize:17,paddingVertical:5,}} >Event</Text>
    </View>
    <View style={styles.NotificationSubTab2}>
      <TouchableOpacity style={styles.NotificationTouchableOpacity1}>
        <Text style={styles.Notification_btn}>Cancel</Text>
      </TouchableOpacity>
      </View>
    </View>

    <View style={styles.NotificationTab}>
    <View style={styles.NotificationSubTab1}>
      <Text style={{fontSize:25,paddingVertical:10,}}>Zone</Text>
      <Text style={{fontSize:17,paddingVertical:5,}} >Event</Text>
    </View>
    <View style={styles.NotificationSubTab2}>
      <TouchableOpacity style={styles.NotificationTouchableOpacity1}>
        <Text style={styles.Notification_btn}>Cancel</Text>
      </TouchableOpacity>
      </View>
    </View>

    <View style={styles.NotificationTab}>
    <View style={styles.NotificationSubTab1}>
      <Text style={{fontSize:25,paddingVertical:10,}}>Zone</Text>
      <Text style={{fontSize:17,paddingVertical:5,}} >Event</Text>
    </View>
    <View style={styles.NotificationSubTab2}>
      <TouchableOpacity style={styles.NotificationTouchableOpacity1}>
        <Text style={styles.Notification_btn}>Cancel</Text>
      </TouchableOpacity>
      </View>
    </View>

    <View style={styles.NotificationTab}>
    <View style={styles.NotificationSubTab1}>
      <Text style={{fontSize:25,paddingVertical:10,}}>Zone</Text>
      <Text style={{fontSize:17,paddingVertical:5,}} >Event</Text>
    </View>
    <View style={styles.NotificationSubTab2}>
      <TouchableOpacity style={styles.NotificationTouchableOpacity1}>
        <Text style={styles.Notification_btn}>Cancel</Text>
      </TouchableOpacity>
      </View>
    </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  NotificationTab:{
   flex:1,
   flexDirection: 'row',
   marginHorizontal:15,
   marginVertical:10,
   paddingHorizontal:20,
   paddingVertical:10,
   borderRadius:20,
   alignItems: 'center',
  },
  NotificationSubTab2:{
    marginLeft:'auto',
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor:'#ffe51e',
    borderRadius: 15, paddingHorizontal: 30, paddingVertical: 10,
  },
});
