import React, {useState, useEffect} from 'react';
import {
  ActivityIndicator,
  StyleSheet,
  Image
} from 'react-native';
import * as Network from 'expo-network';
import { View } from '../components/Themed';

import AsyncStorage from '@react-native-async-storage/async-storage';

const SplashScreen = ({navigation}) => {
  //State for ActivityIndicator animation
  const [animating, setAnimating] = useState(true);

  useEffect(async () => {
    setAnimating(false);
    //Check if user_id is set or not
    //If not then send for Authentication
    //else send to Home Screen
    await Network.getNetworkStateAsync().then(async (network) => {
      await AsyncStorage.getItem('token').then(async (token) => {
        if(token != null){
          if(network.isConnected){
              await AsyncStorage.getItem('version').then(async (currentversion) => {
                await fetch('https://expoapp.bodypower.com/api/version', {
                  method: 'GET',
                  headers: {
                    //Header Defination
                    'Content-Type':
                    'application/json',
                  },
                }).then(async (serverversion) => {
                  console.log("serverversion");
                  // console.log(await serverversion.json());
                  // console.log("currentversion");
                  // console.log(currentversion);
                  await serverversion.json().then(async (laetestversion) => {
                    if(currentversion == null || JSON.parse(currentversion) == laetestversion){
                      AsyncStorage.setItem('currentversion', JSON.stringify(laetestversion))
                      console.log("version set")
                      fetch('https://expoapp.bodypower.com/public/api/zones', {
                        method: 'GET',
                        headers: {
                          //Header Defination
                          'Content-Type':
                          'application/json',
                        },
                      })
                      .then((response) => response.json())
                      .then((responseJson) => {
                        AsyncStorage.setItem('zones', JSON.stringify(responseJson));
                        responseJson.map(async d => {
                          await fetch('https://expoapp.bodypower.com/public/api/zones/'+ d.id, { 
                            method: 'GET',
                            headers: {
                              //Header Defination
                              'Content-Type':
                              'application/json',
                              'Authorization':
                              'Bearer ' + token,
                            },
                          }).then(async (rawdata) => {
                            await rawdata.json().then((json) => {
                              AsyncStorage.setItem('zones_'+d.id, JSON.stringify(json));
                            })
                          })
                        })
                      })
                      fetch('https://expoapp.bodypower.com/public/api/map', {
                        method: 'GET',
                        headers: {
                          //Header Defination
                          'Content-Type':
                          'application/json',
                        },
                      })
                      .then((response) => response.json())
                      .then((responseJson) => {
                        AsyncStorage.setItem('map', JSON.stringify(responseJson));
                      })
                      fetch('https://expoapp.bodypower.com/public/api/events', {
                        method: 'GET',
                        headers: {
                          //Header Defination
                          'Content-Type':
                          'application/json',
                        },
                      })
                      .then((response) => response.json())
                      .then((responseJson) => {
                        AsyncStorage.setItem('events', JSON.stringify(responseJson));
                        responseJson.map(async (d) => {
                          await fetch('https://expoapp.bodypower.com/public/api/events/'+ d.id, { 
                            method: 'GET',
                            headers: {
                              //Header Defination
                              'Content-Type':
                              'application/json',
                              'Authorization':
                              'Bearer ' + token,
                            },
                          }).then( async (rawdata) => {
                            await rawdata.json().then((json) => {
                              AsyncStorage.setItem('events_'+d.id, JSON.stringify(json));
                            })

                          })
                        })
                      })
                      fetch('https://expoapp.bodypower.com/public/api/guests', {
                        method: 'GET',
                        headers: {
                          //Header Defination
                          'Content-Type':
                          'application/json',
                        },
                      })
                      .then((response) => response.json())
                      .then((responseJson) => {
                        AsyncStorage.setItem('guests', JSON.stringify(responseJson));
                        responseJson.map(async d => {
                          await fetch('https://expoapp.bodypower.com/public/api/guests/'+ d.id, { 
                            method: 'GET',
                            headers: {
                              //Header Defination
                              'Content-Type':
                              'application/json',
                              'Authorization':
                              'Bearer ' + token,
                            },
                          }).then(async (rawdata) => {
                            await rawdata.json().then(json => {
                              AsyncStorage.setItem('guests_'+d.id, JSON.stringify(json));
                            })

                          })
                        })
                      })
                    }
                    navigation.replace('Root')
                    console.log("connected")

                  })

                })

              })
            }else{
              navigation.replace('Root')
            }
            console.log("version set 2")
          }
          console.log("version set 3")
          console.log("version set 4")

      })

    })
  });

  

  return (
    <View style={styles.container}>
      <Image
        source={require('../assets/images/splash.png')}
        style={{width: '90%', resizeMode: 'contain', margin: 30}}
      />
      <ActivityIndicator
        animating={animating}
        color="#FFFFFF"
        size="large"
        style={styles.activityIndicator}
      />
    </View>
  );
};

export default SplashScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activityIndicator: {
    alignItems: 'center',
    height: 80,
  },
});