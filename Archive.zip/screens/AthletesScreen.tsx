import * as React from 'react';
import { ScrollView, StyleSheet, Image, Dimensions, TouchableOpacity, Button } from 'react-native';
import ImageView from "react-native-image-viewing";

import { Text, View } from '../components/Themed';
import Bottom from '../components/Bottom';
import { RootTabScreenProps } from '../types';



import AsyncStorage from '@react-native-async-storage/async-storage';


export default function AthletesScreen({ navigation }: RootTabScreenProps<'TabOne'>) {
  const [data, setData] = React.useState([]);
  const [images, setImages] = React.useState([]);
  const [visible, setVisible] = React.useState(false);
  const [index, setIndex] = React.useState(0);
  
  React.useEffect( async () => {
    //Check if user_id is set or not
    //If not then send for Authentication
    //else send to Home Screen
  
    // const token = await AsyncStorage.getItem('token');
    // const rawdata = await fetch('https://expoapp.bodypower.com/public/api/guests', { 
    //       method: 'GET',
    //       headers: {
    //         //Header Defination
    //         'Content-Type':
    //         'application/json',
    //         'Authorization':
    //         'Bearer ' + token,
    //       },
    //     });
    // const json = await rawdata.json();
    // // console.log(json);
    // setData(json);

    const json = await AsyncStorage.getItem('guests');
    setData(JSON.parse(json));
  });
  // console.log(d);
  console.log(data);
  // console.log(d);


  return (
    <View>
      <ImageView
        images={images}
        imageIndex={index}
        visible={visible}
        onRequestClose={() => setVisible(false)}
      />
      <ScrollView>
        {data.map(d => (<View style={styles.separator} lightColor="#fff" darkColor="#242424">
            <View style={styles.container} lightColor="#fff" darkColor="#242424">
              <TouchableOpacity
                onPress={() => {
                  let imagedata = []
                  imagedata.push({'uri': d.thumbnail})
                  d.gallery_images.map(image => imagedata.push({'uri': image.image}))
                  setImages(imagedata);
                  setVisible(true);
                  setIndex(0);
                  // console.log(index);
                }}>
                <Image source={{uri: d.thumbnail}} style={styles.image} />
              </TouchableOpacity>
              {d.gallery_images.length > 0 &&
                <View style={styles.container} lightColor="#fff" darkColor="#242424">
                  <ScrollView horizontal={true} style={styles.eventcontainer}>
                    {d.gallery_images.map((image, index) =>
                      <TouchableOpacity
                        onPress={() => {
                          let imagedata = []
                          imagedata.push({'uri': d.thumbnail})
                          d.gallery_images.map(image => imagedata.push({'uri': image.image}))
                          setImages(imagedata);
                          setVisible(true);
                          setIndex(index+1);
                          // console.log(index);
                        }}>
                        <Image source={{uri: image.image}} style={styles.eventimage} />
                      </TouchableOpacity>
                      ) }
                  </ScrollView>
                </View>
              }
              <View style={styles.textcontainer} lightColor="#fff" darkColor="#242424">
                <View lightColor="#fff" darkColor="#242424">
                  <Text style={styles.title}>{d.name}</Text>
                </View>
                <Text numberOfLines={3}>{d.description}</Text>
                <TouchableOpacity
                  onPress={() => navigation.navigate('Schedule', d.schedule)}
                >
                  <Text style={{ fontWeight: 'bold', marginTop: 10 }}>View Schedule</Text>
                </TouchableOpacity>
              </View>
            </View>
            <View style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'center'}} lightColor="#fff" darkColor="#242424">
              <TouchableOpacity
                onPress={() => navigation.navigate('Zone', d)}
                style={{ marginTop: 5, borderRadius: 5, paddingHorizontal: 5, paddingVertical: 10 }}
              >
                <Text style={{backgroundColor: '#ffe51e', borderRadius: 15, paddingHorizontal: 30, paddingVertical: 10, color: "#000"}}>Book a Meet</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => navigation.navigate('Athlete', d)}
                style={{ marginTop: 5, borderRadius: 5, paddingHorizontal: 5, paddingVertical: 10 }}
              >
                <Text style={{backgroundColor: '#ffe51e', borderRadius: 15, paddingHorizontal: 30, paddingVertical: 10, color: "#000"}}>Know More</Text>
              </TouchableOpacity>
            </View>
        </View>))}
        <Bottom />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
  },
  eventcontainer: {
    flexDirection: 'row'
  },
  textcontainer: {
    marginVertical: 20,
    paddingLeft: 10,
    paddingRight: 10,
  },
  title: {
    marginVertical: 10,
    fontSize: 20,
    fontWeight: 'bold',
  },
  image: {
    width: Dimensions.get('window').width - 25,
    height: ((Dimensions.get('window').width/5)*4)- 20,
    borderRadius: 25,
  },
  eventimage: {
    width: Dimensions.get('window').width/3,
    marginHorizontal: 5,
    borderRadius: 25,
    height: ((Dimensions.get('window').width/5)*4)/3,
  },
  separator: {
    borderRadius: 25,
    paddingVertical: 30,
    marginVertical: 20,
    marginHorizontal: 5,
  },
});
