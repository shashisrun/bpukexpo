import * as React from 'react';
import ImageView from "react-native-image-viewing";
import { CommonActions } from '@react-navigation/native';
import { View } from '../components/Themed';

import AsyncStorage from '@react-native-async-storage/async-storage';

export default function MapScreen({navigation}){
  const [visible, setVisible] = React.useState(true);
  const [data, setData] = React.useState([]);
  React.useEffect(() => {
    const unsubscribe = navigation.addListener('focus', async () => {
      await AsyncStorage.getItem('map').then((json) => {
        console.log(JSON.parse(json));
        setData([{'uri' : JSON.parse(json).map}]);
      })
      // The screen is focused
      // Call any action
      setVisible(true);
    });
    setVisible(false);
    // Return the function to unsubscribe from the event so it gets removed on unmount
    return unsubscribe;
  }, [navigation]);
  
  return (
    <View>
      { visible == true &&
        <ImageView
              images={data}
              imageIndex={0}
              visible={visible}
              onRequestClose={() => {
                setVisible(false);
                navigation.dispatch(CommonActions.goBack())
              }}
          />
      }
    </View>
  )
}
